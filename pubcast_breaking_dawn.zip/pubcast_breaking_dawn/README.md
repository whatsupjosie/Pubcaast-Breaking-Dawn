# PubCast Breaking Dawn

One ZIP. Everything that's real, and everything you need to keep going.

## `WORKING_PROGRAM/`
PubCast, PubPartner, and 2i, exactly as they stood at the end of tonight's
session — including the Foresight shell deployed into `pubcast/static/`, and
the CORS fix already applied inside `pubpartner/pubpartner_federation/service.py`.
`node_modules/` was stripped from `2i-backend/` to keep this sane — run
`npm install` in there before starting it. Start order and commands are in
`CONTINUE_FROM_HERE/RUN_GUIDE.md`.

## `CONTINUE_FROM_HERE/`
Everything for picking this back up, whoever's picking it up:

- **`SESSION_HANDOFF_2026-08-19.md`** — start here. What happened tonight,
  what's actually verified versus assumed, open concerns, and the nominated
  first next step.
- **`RUN_GUIDE.md`** — how to actually start all three services.
- **`docs/`** — the project's own accumulated handoff and engineering docs.
- **`not_yet_integrated/`** — tonight's uploaded character/EQ/memory files.
  Read that folder's own README before merging anything from it in — one of
  these files collides with real working code if dropped in carelessly.
- **`media/`** — the finished brand-video ending.

Read `SESSION_HANDOFF_2026-08-19.md` first. Everything else hangs off it.
